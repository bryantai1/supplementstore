const express = require('express');
const mysql = require('mysql2');
const app = express();
// Create MySQL connection
const connection = mysql.createConnection({
host: 'localhost',
user: 'root',
password: '',
database: 'c237_supermarketapp',
port:3316
});
connection.connect((err) => {
if (err) {
console.error('Error connecting to MySQL:', err);
return;
}
console.log('Connected to MySQL database');
});
// Set up view engine
app.set('view engine', 'ejs');
// enable static files
app.use(express.static('public'));
app.use(express.urlencoded({
    extended:false
}));
// Define routes(RETRIEVE ALL)
// Example:
app.get('/', (req, res) => {
    const sql= 'SELECT * FROM products';
    connection.query('SELECT * FROM products', (error, results) => {
        if (error) {
            console.error('Database query error:', error.message);
            return res.status(500).send('Error Retrieving products');
        }
      res.render('index', { products: results }); // Render HTML page with data
 });
 });
app.get('/editProduct/:id', (req,res)=>{
    const productId = req.params.id;
    const sql ='SELECT * FROM products WHERE productId=?';
    connection.query(sql, [productId], (error, results)=> {
        if(error){
            console.error('Database query error:',error.message);
            return res.status(500).send('Error retrieving product by ID'); 
               }
        if (results.length>0) {
            res.render('editProduct', {products:results[0]});
        }else {
            res.status(404).send('Product not found');
        }
    });
});
app.post('/editProduct/:id', (req,res)=>{
    const productId =req.params.id;
    const {name, quantity, price}=req.body
    const sql ='UPDATE products SET productName = ?, price = ? WHERE productId = ?';

    connection.query(sql,[name, price, productId], (error,results)=>{
        if(error){
            console.error("Error updating product:", error);
            res.status(500).send('Error updating product');
        }else{
            res.redirect('/')
        }
    })
})
app.get('/products/:id',(req,res)=>{
    const productId = req.params.id;
    const sql='SELECT * FROM products WHERE productId = ?';
    connection.query(sql, [productId], (error, results)=> {
        if(error) {
            console.error('Database query error:', error.message);
            return res.status(500).send('Error Retrieving product by ID');

        }

        if (results.length > 0) {
            res.render('products', {products: results[0]});
        } else {
            res.status(404).send('Product not found');
        }

    });
});

app.get('/vitamins/:id',(req,res)=>{
    const productId = req.params.id;
    const sql='SELECT * FROM vitamins WHERE productId = ?';
    connection.query(sql, [productId], (error, results)=> {
        if(error) {
            console.error('Database query error:', error.message);
            return res.status(500).send('Error Retrieving product by ID');

        }

        if (results.length > 0) {
            res.render('vitamins', {vitamins: results[0]});
        } else {
            res.status(404).send('Product not found');
        }

    });
});
app.get('/protein/:id',(req,res)=>{
    const productId = req.params.id;
    const sql='SELECT * FROM protein WHERE productId = ?';
    connection.query(sql, [productId], (error, results)=> {
        if(error) {
            console.error('Database query error:', error.message);
            return res.status(500).send('Error Retrieving product by ID');

        }

        if (results.length > 0) {
            res.render('viewprotein', {protein: results[0]});
        } else {
            res.status(404).send('Product not found');
        }

    });
});
app.get('/wellbeing/:id',(req,res)=>{
    const productId = req.params.id;
    const sql='SELECT * FROM wellbeing WHERE productId = ?';
    connection.query(sql, [productId], (error, results)=> {
        if(error) {
            console.error('Database query error:', error.message);
            return res.status(500).send('Error Retrieving product by ID');

        }

        if (results.length > 0) {
            res.render('viewwellbeing', {wellbeing: results[0]});
        } else {
            res.status(404).send('Product not found');
        }

    });
});


app.get('/addProduct', (req,res)=>{
    res.render('addProduct');

});

app.post('/addProduct',(req,res)=>{
    const {name, price,image}=req.body;
    const sql ='INSERT INTO products (productName, price, image) VALUES (?,?,?) ';
    connection.query(sql,[name, price, image], (error, results)=>{
        if(error) {
            console.error("error adding product:",error);
            res.status(500).send('error adding product');

        } else {
            res.redirect('/');
        };
    });
});

app.get('/addproteinProduct', (req,res)=>{
    res.render('addproteinProduct');

});

app.post('/addproteinProduct',(req,res)=>{
    const {name, price,image}=req.body;
    const sql ='INSERT INTO protein (productName, price, image) VALUES (?,?,?) ';
    connection.query(sql,[name, price, image], (error, results)=>{
        if(error) {
            console.error("error adding product:",error);
            res.status(500).send('error adding product');

        } else {
            res.redirect('/');
        };
    });
});
app.get('/protein', (req, res) => {
    const sql= 'SELECT * FROM protein';
    connection.query('SELECT * FROM protein', (error, results) => {
        if (error) {
            console.error('Database query error:', error.message);
            return res.status(500).send('Error Retrieving products');
        }
      res.render('protein', { protein: results }); // Render HTML page with data
 });
 });

 app.get('/vitamins', (req, res) => {
    const sql= 'SELECT * FROM vitamins';
    connection.query('SELECT * FROM vitamins', (error, results) => {
        if (error) {
            console.error('Database query error:', error.message);
            return res.status(500).send('Error Retrieving products');
        }
      res.render('vitamins', { vitamins: results }); // Render HTML page with data
 });
 });
 app.get('/addvitaminsProduct', (req,res)=>{
    res.render('addvitaminsProduct');
 })
 app.post('/addvitaminsProduct',(req,res)=>{
    const {name, price,image}=req.body;
    const sql ='INSERT INTO vitamins (productName, price, image) VALUES (?,?,?) ';
    connection.query(sql,[name, price, image], (error, results)=>{
        if(error) {
            console.error("error adding product:",error);
            res.status(500).send('error adding product');

        } else {
            res.redirect('/');
        };
    });
});
app.get('/wellbeing', (req, res) => {
    const sql= 'SELECT * FROM wellbeing';
    connection.query('SELECT * FROM wellbeing', (error, results) => {
        if (error) {
            console.error('Database query error:', error.message);
            return res.status(500).send('Error Retrieving products');
        }
      res.render('wellbeing', { wellbeing: results }); // Render HTML page with data
 });
 });
 app.get('/addwellbeingProduct', (req,res)=>{
    res.render('addwellbeingProduct');
 })
 app.post('/addwellbeingProduct',(req,res)=>{
    const {name, price,image}=req.body;
    const sql ='INSERT INTO wellbeing (productName, price, image) VALUES (?,?,?) ';
    connection.query(sql,[name, price, image], (error, results)=>{
        if(error) {
            console.error("error adding product:",error);
            res.status(500).send('error adding product');

        } else {
            res.redirect('/');
        };
    });
});
app.get('/deleteProduct/:id', (req,res)=>{
    const productId =req.params.id;
    const sql='DELETE FROM products WHERE productId =?';
    connection.query(sql,[productId], (error, results)=>{
        if(error) {
            console.error("Error Deleting Product:",error);
            res.status(500).send('Error Deleting Product');
        
        } else {
            res.redirect
        }('/');
    })
})





const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));